//
//  main.m
//  BluetoothDemo
//
//  Created by 郑吕杰 on 2020/10/13.
//  Copyright © 2020年 zhenglj. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
