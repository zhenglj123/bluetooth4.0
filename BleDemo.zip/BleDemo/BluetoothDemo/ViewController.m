//
//  ViewController.m
//  BluetoothDemo
//
//  Created by 郑吕杰 on 2020/10/13.
//  Copyright © 2020年 zhenglj. All rights reserved.
//

#import "ViewController.h"
#import "Bluetooth.h"
#import "BlueModel.h"
#import "HProgressHUD.h"
#import "SingletonManager.h"
#import "SendViewController.h"

#define UUID_String @"0000FEE9-0000-1000-8000-00805F9B34FB"
#define CSAlert(_S_) \
UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"" message:_S_ preferredStyle:UIAlertControllerStyleAlert];[alert addAction:[UIAlertAction actionWithTitle:@"知道了" style:UIAlertActionStyleDefault handler:nil]];[self presentViewController:alert animated:YES completion:nil];

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource,HProgressHUDDelegate,AutomaticConnectionDelegate>
{
    UITableView *mytableView;
    UILabel * nameLabel; //蓝牙名字
    UILabel * uuidStrLabel;  //UUID
    UILabel * distanceLabel; //距离
    HProgressHUD * HUD;
}
@property (nonatomic, strong) NSMutableArray *blueListArr;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.title = @"BLEDemo";
    self.blueListArr = [[NSMutableArray alloc]init];
    
    //加载圈
    HUD = [[HProgressHUD alloc]initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:HUD];
    HUD.delegate = self;
    HUD.animationType = HProgressHUDAnimationZoom;
    HUD.labelText = @"连接中";
	
    //创建展示列表
    [self createTableView];
    
    [Bluetooth shareInstance].delegate = self;
    //删除自动重连
    [[Bluetooth shareInstance] createAutomaticConnectionEquipmenWithSetOrDelate:DelateAutomaticConnectionEquipmen Peripheral:nil];
	[[NSUserDefaults standardUserDefaults] setObject:nil forKey:@"DeviceUUID"];
	[[NSUserDefaults standardUserDefaults] synchronize];
	
	[[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(didHaveAutoConnection) name:PostAutoConnectionNotificaiton object:nil];
	
	UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
	label.text = @"请打开系统蓝牙";
	label.textColor = [UIColor clearColor];
	label.textAlignment = NSTextAlignmentCenter;
	label.backgroundColor = [UIColor blackColor];
	label.alpha = 0.5;
	label.userInteractionEnabled = NO;
	//监听蓝牙状态
	[[Bluetooth shareInstance] returnBluetoothStateWithBlock:^(NSInteger state) {
		if (state != 5) {
			[self.view addSubview:label];
		} else {
			[label removeFromSuperview];
           static dispatch_once_t disOnce;
           dispatch_once(&disOnce, ^ {
			//搜索蓝牙设备
			[self scanBluetooths];
           });
             
			//是否有UUID，如果有自动重连
			NSString * uuid = [[NSUserDefaults standardUserDefaults] objectForKey:@"DeviceUUID"];
			if (uuid.length > 0) {
				CBPeripheral * p = [[Bluetooth shareInstance] retrievePeripheralWithUUIDString:uuid];
				
				[Bluetooth shareInstance] .UUIDString = UUID_String;
				[self autoCollectBluetoothWithPeripheral:p];
			}
		}
	}];
}

-(void)viewDidDisappear:(BOOL)animated
{
    [HUD hide:YES];
}

-(void)showAlerts:(NSString *)messages action:(void(^)())action{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"蓝牙设备信息" message:messages preferredStyle:UIAlertControllerStyleAlert];
  [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:action]];
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
      NSLog(@"用户选择取消");  //这里写选择取消之后的操作
    }]];
  [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark --- 创建蓝牙设备列表
-(void)createTableView
{
    mytableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight-64) style:UITableViewStylePlain];
    mytableView.delegate = self;
    mytableView.dataSource = self;
    [self.view addSubview:mytableView];
}

#pragma mark --- 有自动重连设备
-(void)autoCollectBluetoothWithPeripheral:(CBPeripheral *)p
{
	[HUD show:YES];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(30.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
         [self->HUD hide:YES];
       });
  
	//停止扫描
	[[Bluetooth shareInstance] stopScan];
	
	[[Bluetooth shareInstance] connectPeripheral:p completeBlock:^(CBPeripheral *peripheral, CBService *service, CBCharacteristic *character) {
        NSLog(@"链接成功:%@  外设蓝牙服务:%@",peripheral.name,service);
		[self->HUD hide:YES];
		
		//当前蓝牙model
		BlueModel * blueModel = [[BlueModel alloc]init];
		blueModel.blueName = peripheral.name;
		blueModel.peripheral = peripheral;
		blueModel.UUIDString = peripheral.identifier.UUIDString;
		
		[SingletonManager shareInstance].GPrint_Chatacter = [Bluetooth shareInstance] .writeCharacteristic;
		[SingletonManager shareInstance].GPrint_Peripheral = peripheral;
		
		//本地保存
		[[NSUserDefaults standardUserDefaults] setObject:blueModel.UUIDString forKey:@"DeviceUUID"];
		[[NSUserDefaults standardUserDefaults] synchronize];
		
		SendViewController *sendVC = [[SendViewController alloc]init];
		[self.navigationController pushViewController:sendVC animated:YES];
	} failBlock:^(CBPeripheral *peripheral, NSError *error) {
		NSLog(@"链接失败");
        [self->HUD hide:YES];
	}];
}

/*
 * CBPeripheral 蓝牙外设，比如蓝牙手环、蓝牙心跳监视器、蓝牙打印机。
 * CBCentralManager 蓝牙外设管理中心，与手机的蓝牙硬件模板关联，可
   以获取到手机中蓝牙模块的一些状态等，但是管理的就是蓝牙外设。
 * CBService 蓝牙外设的服务，每一个蓝牙外设都有0个或者多个服务。而每
   一个蓝牙服务又可能包含0个或者多个蓝牙服务，也可能包含0个或者多个蓝牙特性。
 * CBCharacteristic 每一个蓝牙特性中都包含有一些数据或者信息。
 */
#pragma mark --- 搜索蓝牙设备
-(void)scanBluetooths
{   //scanForPeripheralsWithPrefixName 用预固定名称扫描硬件 TWS-i7(QJB2 服务FEE7) F9 BT-SPEAKER
    [[Bluetooth shareInstance] scanForPeripheralsWithPrefixName:nil discoverPeripheral:^(CBCentralManager *central, CBPeripheral *peripheral, NSDictionary *advertisementData, NSNumber *RSSI) {
        NSLog(@"搜索到了设备:%@",peripheral.name);
        
        NSInteger perpheralIndex = -1 ;
        for (int i = 0;  i < self.blueListArr.count; i++) {
            BlueModel *model = [[BlueModel alloc]init];
            model = self.blueListArr[i];
            if ([model.peripheral.identifier isEqual:peripheral.identifier]) {
                perpheralIndex = i ;
                break ;
            }
        }
        BlueModel *model = [[BlueModel alloc]init];
        model.blueName = peripheral.name;
        model.peripheral = peripheral;
        model.UUIDString = peripheral.identifier.UUIDString;
        double min = [[Bluetooth shareInstance]  bleRssiToNumber:RSSI];
        model.distance = [NSString stringWithFormat:@"%.2f",min];
        if (perpheralIndex != -1) {
            [self.blueListArr replaceObjectAtIndex:perpheralIndex withObject:model];
        }
        else{
            [self.blueListArr addObject:model];
        }
        [self->mytableView reloadData];
    }];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.blueListArr.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    BlueModel *blueModel = self.blueListArr[indexPath.row];
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 5, ScreenWidth-20, 20)];
        [cell addSubview:nameLabel];
        
        uuidStrLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 25, ScreenWidth*3/4, 60)];
        uuidStrLabel.font = [UIFont systemFontOfSize:13];
        uuidStrLabel.numberOfLines = 3;
        [cell addSubview:uuidStrLabel];
        
        distanceLabel = [[UILabel alloc]initWithFrame:CGRectMake(ScreenWidth*3/4, 5, ScreenWidth/4-20, 20)];
        distanceLabel.font = [UIFont systemFontOfSize:13];
        distanceLabel.textAlignment = NSTextAlignmentRight;
        [cell addSubview:distanceLabel];
                 
        UIButton *bleB = [UIButton buttonWithType:UIButtonTypeCustom];
        [bleB setFrame:CGRectMake(ScreenWidth*3/4, 30, 40, 22)];
        [bleB setTitle:@"搜索" forState:UIControlStateNormal];
        bleB.titleLabel.font = [UIFont systemFontOfSize:15];
        [bleB setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
        [bleB addTarget:self action:@selector(bleStartScanClick) forControlEvents:UIControlEventTouchUpInside];
        [cell addSubview:bleB];
      
        UIButton *bleBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [bleBtn setFrame:CGRectMake(ScreenWidth*3/4+50, 30, 40, 22)];
        [bleBtn setTitle:@"停止" forState:UIControlStateNormal];
        bleBtn.titleLabel.font = [UIFont systemFontOfSize:15];
        [bleBtn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
        [bleBtn addTarget:self action:@selector(bleStopScanClick) forControlEvents:UIControlEventTouchUpInside];
        [cell addSubview:bleBtn];
      
        UIButton *bleA = [UIButton buttonWithType:UIButtonTypeCustom];
        [bleA setFrame:CGRectMake(ScreenWidth*3/4, 55, 40, 22)];
        [bleA setTitle:@"音乐" forState:UIControlStateNormal];
        bleA.titleLabel.font = [UIFont systemFontOfSize:15];
        [bleA setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
        [bleA addTarget:self action:@selector(music) forControlEvents:UIControlEventTouchUpInside];
        [cell addSubview:bleA];
        
        UIButton *bleW = [UIButton buttonWithType:UIButtonTypeCustom];
        [bleW setFrame:CGRectMake(ScreenWidth*3/4+50, 55, 40, 22)];
        [bleW setTitle:@"灯光" forState:UIControlStateNormal];
        bleW.titleLabel.font = [UIFont systemFontOfSize:15];
        [bleW setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
        [bleW addTarget:self action:@selector(writeData) forControlEvents:UIControlEventTouchUpInside];
        [cell addSubview:bleW];
        
    }
    while ([cell.contentView.subviews lastObject])
    {
        [(UIView *)[cell.contentView.subviews lastObject] removeFromSuperview];
    }
   
    nameLabel.text = blueModel.blueName;
    uuidStrLabel.text = [NSString stringWithFormat:@"设备:%@",blueModel.peripheral];
    distanceLabel.text = [NSString stringWithFormat:@"距离：%@米",blueModel.distance];
    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 90;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [HUD show:YES];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(30.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
      [self->HUD hide:YES];
    });
  
    //停止扫描
    [[Bluetooth shareInstance] stopScan];
    
    BlueModel *blueModel = self.blueListArr[indexPath.row];
    //设置目标设备特征UUID
    [Bluetooth shareInstance] .UUIDString = UUID_String;
    //连接设备
    [[Bluetooth shareInstance] connectPeripheral:blueModel.peripheral completeBlock:^(CBPeripheral *peripheral, CBService *service, CBCharacteristic *character) {
        NSLog(@"链接成功:%@",peripheral.name);
		[self->HUD hide:YES];
        
        [SingletonManager shareInstance].GPrint_Chatacter = [Bluetooth shareInstance] .writeCharacteristic;
        [SingletonManager shareInstance].GPrint_Peripheral = peripheral;
		
		//本地保存
		[[NSUserDefaults standardUserDefaults] setObject:blueModel.UUIDString forKey:@"DeviceUUID"];
		[[NSUserDefaults standardUserDefaults] synchronize];
		
        //设置自动重连
//        [[Bluetooth shareInstance] createAutomaticConnectionEquipmenWithSetOrDelate:SetAutomaticConnectionEquipmen Peripheral:peripheral];
		
        SendViewController *sendVC = [[SendViewController alloc]init];
        [self.navigationController pushViewController:sendVC animated:YES];
        
    } failBlock:^(CBPeripheral *peripheral, NSError *error) {
        NSLog(@"链接失败");
        [self->HUD hide:YES];
    }];
}

-(void)didHaveAutoConnection
{
    [HUD show:YES];
}

#pragma mark --- 有自动连接设备走到这里
-(void)connectionWithPerpheral:(CBPeripheral *)peripheral
{
    [Bluetooth shareInstance].UUIDString = UUID_String;
    [[Bluetooth shareInstance]createCharacticWithPeripheral:peripheral UUIDString:UUID_String];
    
    [SingletonManager shareInstance].GPrint_Chatacter = [Bluetooth shareInstance] .writeCharacteristic;
    [SingletonManager shareInstance].GPrint_Peripheral = peripheral;
    
    [HUD hide:YES];
    SendViewController *sendVC = [[SendViewController alloc]init];
    [self.navigationController pushViewController:sendVC animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)bleStopScanClick{
  CSAlert(@"停止扫描");
  [[Bluetooth shareInstance] stopScan];
}

-(void)bleStartScanClick{
  CSAlert(@"开始扫描");
  [self scanBluetooths];
}

-(void)writeData{
    [self showAlerts:@"写入数据:0x01" action:^{
        
    }];
}

- (void)music{
   //获取音频文件
   NSURL *path = [NSURL fileURLWithPath:[[NSBundle mainBundle]pathForResource:@"helloworld" ofType:@"mp3"]];
   //将文件写入内存
   NSData *data = [NSData dataWithContentsOfURL:path];
   NSString *filePath = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/helloworld.mp3"]];
   [data writeToFile:filePath atomically:YES];
   //从本地读取文件并播放
   _player = [[AVAudioPlayer alloc]initWithContentsOfURL:[NSURL URLWithString:filePath] error:nil];
   [_player play];
}

@end
