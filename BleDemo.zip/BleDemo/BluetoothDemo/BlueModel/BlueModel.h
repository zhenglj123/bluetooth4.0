//
//  BlueModel.h
//  BluetoothDemo
//
//  Created by 郑吕杰 on 2020/10/13.
//  Copyright © 2020年 zhenglj. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface BlueModel : NSObject
//对接CBPeripheral属性
@property (nonatomic, strong) NSString *blueName;   //设备名称
@property (nonatomic, strong) CBPeripheral *peripheral;//设备
@property (nonatomic, strong) CBCharacteristic * GPrint_Chatacter;//蓝牙特征
@property (nonatomic, strong) NSString * UUIDString; //UUID
@property (nonatomic, strong) NSString * distance;  //中心到外设的距离

@end
