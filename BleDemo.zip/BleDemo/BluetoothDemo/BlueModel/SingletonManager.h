//
//  SingletonManager.h
//  BluetoothDemo
//
//  Created by 郑吕杰 on 2020/10/13.
//  Copyright © 2020年 zhenglj. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface SingletonManager : NSObject

@property (strong, nonatomic)   CBPeripheral * GPrint_Peripheral;//当前连接的Peripheral
@property (strong, nonatomic)   CBCharacteristic * GPrint_Chatacter;//当前连接的Chatacter

+(SingletonManager *)shareInstance;

@end
