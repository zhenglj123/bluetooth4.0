//
//  BlueModel.m
//  BluetoothDemo
//
//  Created by 郑吕杰 on 2020/10/13.
//  Copyright © 2020年 zhenglj. All rights reserved.
//

#import "BlueModel.h"

@implementation BlueModel

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end
