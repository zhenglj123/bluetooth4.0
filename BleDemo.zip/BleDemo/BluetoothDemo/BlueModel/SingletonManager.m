//
//  SingletonManager.m
//  BluetoothDemo
//
//  Created by 郑吕杰 on 2020/10/13.
//  Copyright © 2020年 zhenglj. All rights reserved.
//

#import "SingletonManager.h"

@implementation SingletonManager

+(SingletonManager *)shareInstance
{
    static SingletonManager * singletonManager = nil;
    @synchronized(self){
        if (!singletonManager) {
            singletonManager = [[SingletonManager alloc]init];
        }
    }
    return singletonManager;
}

@end
