//
//  SendViewController.h
//  BluetoothDemo
//
//  Created by 郑吕杰 on 2020/10/13.
//  Copyright © 2020年 zhenglj. All rights reserved.
//

#import <UIKit/UIKit.h>

#define ScreenWidth [UIScreen mainScreen].bounds.size.width
#define ScreenHeight [UIScreen mainScreen].bounds.size.height

@interface SendViewController : UIViewController

@end
