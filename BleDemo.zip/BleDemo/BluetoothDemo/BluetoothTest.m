//
//  BluetoothTest.m
//  BluetoothDemo
//
//  Created by Zhenglj on 2020/10/21.
//  Copyright © 2020 Zhenglj. All rights reserved.
//

#import "BluetoothTest.h"
#import <CoreBluetooth/CoreBluetooth.h>

@interface BluetoothTest ()<CBPeripheralDelegate,CBCentralManagerDelegate>

@end

@implementation BluetoothTest

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //1、创建蓝牙管理中心，也可设置子线程
  CBCentralManager *manager = [[CBCentralManager alloc] initWithDelegate:self queue:dispatch_get_main_queue()];
  
}

//-(void)centralmanagerDidUpdateState:(CBCentralManager *)central{
//    NSLog(@"初始化完就调用:%@",central);
//  switch(central.state) {
//    case CBCentralManagerStatePoweredOn:
//      NSLog(@"蓝牙打开");
//      break;
//    case CBCentralManagerStatePoweredOff:
//      NSLog(@"蓝牙关闭");
//      break;
//
//
//
//}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
